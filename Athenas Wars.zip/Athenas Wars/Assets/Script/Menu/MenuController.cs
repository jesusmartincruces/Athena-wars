﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuController : MonoBehaviour
{
    public GameObject menu;
    public GameObject controlsMenu;
    public GameObject optionsMenu;
    // Start is called before the first frame update
    void Start()
    {
        menu.SetActive(true);
        controlsMenu.SetActive(false);
        optionsMenu.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void NewGame() {
        SceneManager.LoadScene("Game");
    }

    public void ExitGame() {
        Application.Quit();
    }

    public void GoToControlsMenu() {
        menu.SetActive(false);
        controlsMenu.SetActive(true);
        optionsMenu.SetActive(false);
    }

    public void GoToOptionsMenu() {
        menu.SetActive(false);
        controlsMenu.SetActive(false);
        optionsMenu.SetActive(true);
    }

    public void GoToMenu() {
        menu.SetActive(true);
        controlsMenu.SetActive(false);
        optionsMenu.SetActive(false);
    }
}
