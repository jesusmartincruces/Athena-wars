﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PlayerNumber
{
    One, Two
}
public class PlayerController : MonoBehaviour
{
    
    public PlayerNumber playerNumber;

    public float speed;

    public Transform tankBody;

    public float rotSpeed;
    public float turretRotSpeed;

    public Transform turret;



    Rigidbody rB;

    void Start() {
        rB = GetComponent<Rigidbody>();
    }


    void Update() {
        Movement();
        RotateTurret();
    }

    void Movement() {
        float h = Input.GetAxisRaw("P" + ((int)playerNumber + 1) + " Horizontal");
        float v = Input.GetAxisRaw("P" + ((int)playerNumber + 1) + " Vertical");

        Vector3 movement = new Vector3(h, 0f, v);
        //Normalizamos el vector - mvoimento en diagonal se produzca a la misma velocidad
        movement.Normalize();

        if (Mathf.Abs(h) > 0 || Mathf.Abs(v) > 0) {
            RotateBody(movement);
        }



        rB.MovePosition(transform.position + movement * speed * Time.deltaTime);

        Debug.DrawRay(transform.position, movement, Color.red);


    }

    void RotateBody(Vector3 direction) {
        tankBody.rotation = Quaternion.Lerp(tankBody.rotation, Quaternion.LookRotation(direction), rotSpeed * Time.deltaTime);
    }

    void RotateTurret() {
        float rH = Input.GetAxis("P" + ((int)playerNumber + 1) + " RightHorizontal");
        float rV = Input.GetAxis("P" + ((int)playerNumber + 1) + " RightVertical");


#if UNITY_EDITOR


        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

                RaycastHit hit;

                Physics.Raycast(ray,out hit, Mathf.Infinity);
                if (hit.collider) {
                    Vector3 dir = hit.point - transform.position;
                    Quaternion lookRotation = Quaternion.LookRotation(dir);

                    turret.rotation = Quaternion.Lerp(turret.rotation, new Quaternion(0f, lookRotation.y, 0f, lookRotation.w),turretRotSpeed * Time.deltaTime);
                }
#endif


#if UNITY_STANDALONE

            if (Mathf.Abs(rH) > 0 || Mathf.Abs(rV) > 0) {
                Vector3 lookDirection = new Vector3(rH, 0f, rV);

                turret.rotation = Quaternion.Lerp(turret.rotation, Quaternion.LookRotation(lookDirection), turretRotSpeed * Time.deltaTime);
            }


#endif
        
    }
}
