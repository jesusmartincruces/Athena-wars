﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public GameObject hangar1;
    public GameObject hangar2;

    public GameObject victoria1;
    public GameObject derrota1;
    public GameObject victoria2;
    public GameObject derrota2;

    public GameObject reinicio;
    public GameObject menu;
    public GameObject salir;
    public GameObject seleccionPersonajes;
    public GameObject j1;
    public GameObject j2;

    public Transform respawnJ1;
    public Transform respawnJ2;

    public GameObject j1HeavyTank;
    public GameObject j1LightTank;
    public GameObject j2HeavyTank;
    public GameObject j2LightTank;
    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 0;
        victoria1.SetActive(false);
        victoria2.SetActive(false);
        derrota1.SetActive(false);
        derrota2.SetActive(false);
        reinicio.SetActive(false);
        menu.SetActive(false);
        salir.SetActive(false);
        seleccionPersonajes.SetActive(true);
        j1.SetActive(true);
        j2.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if(hangar1 == null) {
            Time.timeScale = 0;
            victoria2.SetActive(true);
            derrota1.SetActive(true);
            reinicio.SetActive(true);
            menu.SetActive(true);
            salir.SetActive(true);
        }
        if(hangar2 == null) {
            Time.timeScale = 0;
            victoria1.SetActive(true);
            derrota2.SetActive(true);
            reinicio.SetActive(true);
            menu.SetActive(true);
            salir.SetActive(true);
        }
    }

    public void Restart() {
        SceneManager.LoadScene("Game");
    }

    public void GoToMenu() {
        SceneManager.LoadScene("StartMenu");
    }

    public void Exit() {
        Application.Quit();
    }

    public void J1Pesado() {
        Instantiate(j1HeavyTank, respawnJ1.position, respawnJ1.rotation);
        j1.SetActive(false);
        j2.SetActive(true);
    }

    public void J1Ligero() {
        Instantiate(j1LightTank, respawnJ1.position, respawnJ1.rotation);
        j1.SetActive(false);
        j2.SetActive(true);
    }

    public void J2Pesado() {
        Instantiate(j2HeavyTank, respawnJ2.position, respawnJ2.rotation);
        j2.SetActive(false);
        seleccionPersonajes.SetActive(false);
        Time.timeScale = 1;
    }

    public void J2Ligero() {
        Instantiate(j2LightTank, respawnJ2.position, respawnJ2.rotation);
        j2.SetActive(false);
        seleccionPersonajes.SetActive(false);
        Time.timeScale = 1;
    }
}
