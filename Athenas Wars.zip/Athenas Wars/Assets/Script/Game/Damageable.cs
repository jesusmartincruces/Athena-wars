﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damageable : MonoBehaviour
{

    public float maxHealth;
    public float currentHealth;

    public bool invulnerable;

    public enum OnDeathAction
    {
        Respawn, Destroy
    }
    public OnDeathAction onDeathAction;

    public Transform respawnPoint;
    public float respawnDelay;
    public Respawner respawner;
    // Start is called before the first frame update
    void Start()
    {
        gameObject.tag = "Damageable";
    }

    private void OnEnable() {
        currentHealth = maxHealth;
    }

    public void GetDamage(bool lethal,float _damage = 0) {
        if (lethal) {
            currentHealth -= currentHealth;
        }else if (!invulnerable) {
            currentHealth -= _damage;
        } else {
            return;
        }


        if (currentHealth <= 0) {
            Death();
        }
    }

    void Death() {
        switch (onDeathAction) {
            case OnDeathAction.Respawn:
                respawner.RespawnCaller(gameObject, respawnDelay, respawnPoint);
                gameObject.SetActive(false);
                break;
            case OnDeathAction.Destroy:
                Destroy(gameObject);
                break;
            
        }



        
    }

    

  
}
