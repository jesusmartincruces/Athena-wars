﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyBehaviour : MonoBehaviour
{
    [Header("IA")]
    public Transform nearestBase;
    public float speed;
    public float minDistance;
    public float maxDistance;
    public float randomDistance;
    public bool attacking;
    public float rotSpeed;


    [Header("Attack")]
    public GameObject bulletPrefab;
    public Transform shoootingPoint;
    public float bulletSpeed;
    public float damage;
    public float attackDelay;
    float attackChrono;
    
    

    [HideInInspector]
    NavMeshAgent agent;
    public EnemySpawner enemySpawner;
    NavMeshObstacle navObs;

    // Start is called before the first frame update
    void Start()
    {

        agent = GetComponent<NavMeshAgent>();
        navObs = GetComponent<NavMeshObstacle>();

        agent.speed = speed;

        nearestBase = GetNearestBase();

        agent.SetDestination(nearestBase.position);

        randomDistance = Random.Range(minDistance, maxDistance);
    }

    // Update is called once per frame
    void Update()
    {
        CheckBaseDistance();
    }

    
    Transform GetNearestBase() {
        Transform hangar1 = GameObject.Find("Hangar1").transform;
        Transform hangar2 = GameObject.Find("Hangar2").transform;

        if(Vector3.Distance(transform.position,hangar1.position) < Vector3.Distance(transform.position, hangar2.position)) {
            return hangar1;
        } else {
            return hangar2;
        }
    }

    IEnumerator Attack() {
        attacking = true;
        agent.enabled = false;
        navObs.enabled = true;

        attackChrono = attackDelay;

        while (true) {
            if (nearestBase) {
                transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.LookRotation(nearestBase.position - transform.position), rotSpeed * Time.deltaTime);
                
                if(attackChrono >= 0) {
                    attackChrono -= Time.deltaTime;
                } else{
                    attackChrono = attackDelay;
                    GameObject tempBullet = Instantiate(bulletPrefab, shoootingPoint.position, shoootingPoint.rotation);
                    tempBullet.GetComponent<Rigidbody>().AddForce(tempBullet.transform.forward * bulletSpeed);
                    tempBullet.GetComponent<DamageDealer>().damage = damage;
                }
            } else {
                Destroy(gameObject);
            }

            yield return null;
        }
    }

    void CheckBaseDistance() {
        if (!attacking) {
            if (agent.remainingDistance < randomDistance) {
                StartCoroutine(Attack());
            }
        } else {
            return;
        }
        
    }

    private void OnDestroy() {
        enemySpawner.enemiesCounter--;
    }

}
