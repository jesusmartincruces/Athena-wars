﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShoot : MonoBehaviour
{
    PlayerNumber playerNumber;


    [Header("Bullet config")]
    public GameObject bulletPrefab; // Referencia de la bala
    public Transform shootingPoint; // Referencia del lugar donde se instancia
    public bool canShoot = true; // Controlamos que el jugador pueda disparar
    public float cooldown;
    public float bulletDamage;
    public int bulletSpeed;


    public enum ShootingMode
    {
        Auto, Semi, Burst
    }

    [Header("Shooting config")]
    public ShootingMode shootingMode; // Enumerador para seleccionar el tipo de disparo
    public int burst;
    public float burstCooldown;



    private void Start() {
        playerNumber = GetComponent<PlayerController>().playerNumber;
    }

    // Update is called once per frame
    void Update()
    {
        switch (shootingMode) {
            case ShootingMode.Auto:
                if (Input.GetButton("P" + ((int) playerNumber + 1) + " Shoot")) {
                    StartCoroutine(Shoot(false));
                }
                break;
            case ShootingMode.Semi:
                if (Input.GetButtonDown("P" + ((int)playerNumber + 1) + " Shoot")) {
                    StartCoroutine(Shoot(false));
                }
                break;
            case ShootingMode.Burst:
                if (Input.GetButtonDown("P" + ((int)playerNumber + 1) + " Shoot")) {
                    StartCoroutine(Shoot(true));
                }
                break;
            default:
                break;
        }
    }

    private void OnEnable() {
        canShoot = true;
    }


    IEnumerator Shoot(bool isBurst) {
        if (canShoot) {

            canShoot = false;

            if (isBurst) {

                for (int i = 0; i < burst; i++) {
                    GameObject tempBullet = Instantiate(bulletPrefab, shootingPoint.position, shootingPoint.rotation);
                    tempBullet.GetComponent<DamageDealer>().damage = bulletDamage;
                    tempBullet.GetComponent<Rigidbody>().AddForce(tempBullet.transform.up * bulletSpeed);
                    

                    yield return new WaitForSeconds(burstCooldown);
                }

                yield return new WaitForSeconds(cooldown);

            } else {
                GameObject tempBullet = Instantiate(bulletPrefab, shootingPoint.position, shootingPoint.rotation);
                tempBullet.GetComponent<Rigidbody>().AddForce(tempBullet.transform.up * bulletSpeed);

                yield return new WaitForSeconds(cooldown);
            }

            

            canShoot = true;
        }
    }
}
