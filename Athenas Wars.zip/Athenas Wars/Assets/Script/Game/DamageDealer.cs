﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageDealer : MonoBehaviour
{

    public float damage;

    public bool destroyOnHits;

    private void OnTriggerEnter(Collider other) {
        if (other.CompareTag("Damageable")) {
            other.GetComponent<Damageable>().GetDamage(false,damage);
        }

        if (destroyOnHits) {
            Destroy(gameObject);
        }
    }
}
