﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Respawner : MonoBehaviour
{
    public void RespawnCaller(GameObject item, float delay, Transform respawnPos) {
        StartCoroutine(Respawn(item, delay, respawnPos));
    }

    IEnumerator Respawn(GameObject item, float delay, Transform respawnPos) {
        yield return new WaitForSeconds(delay);
        Debug.Log($"Respawnea : {item.name}");
        item.SetActive(true);
        item.transform.position = respawnPos.position;
        item.transform.rotation = respawnPos.rotation;
    }
}
