﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public PowerUpsTypes powerUpsType;
    public float duration;

    private void OnTriggerEnter(Collider other) {
        if(other.gameObject.layer == LayerMask.NameToLayer("Player")) {
            PowerUpsController pUpC;
            if(pUpC = other.GetComponent<PowerUpsController>()) {
                if (!pUpC.powerUpActivated) {
                    pUpC.StartCoroutine(pUpC.ActivatePowerUp(powerUpsType, duration));
                    Destroy(gameObject);
                }
            }
        }
    }
}
