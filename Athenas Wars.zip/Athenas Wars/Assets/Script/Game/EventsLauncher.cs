﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class EventsLauncher : MonoBehaviour
{
    public UnityEvent onDestroyAction;

    private void OnDestroy() {
        onDestroyAction.Invoke();
    }
}
