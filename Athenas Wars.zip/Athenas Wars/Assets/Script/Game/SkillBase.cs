﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillBase : MonoBehaviour
{

    public string inputName;

    public float skillCooldown;
    public bool skillOnCooldown;
    

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown(inputName) && !skillOnCooldown) {
            StartCoroutine(InitSkill());
        }
    }

    IEnumerator InitSkill() {
        skillOnCooldown = true;
        yield return StartCoroutine(Skill());
        yield return new WaitForSeconds(skillCooldown);
        skillOnCooldown = false;
    }

    public virtual IEnumerator Skill() {
        yield return null;
    }
}
