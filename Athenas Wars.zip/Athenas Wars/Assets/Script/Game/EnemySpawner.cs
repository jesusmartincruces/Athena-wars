﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{

    [Header("Collections")]
    public GameObject[ ] enemies;

    public Transform enemySpawnPointsContainer;
    public Transform[ ] enemySpawnPoints;

    [Header("Spawn config")]
    public bool enableSpawning = true;
    public float spawnDelay;
    public int enemiesCounter;
    public int enemiesLimit;

    
    void Start()
    {
        enemySpawnPoints = new Transform[enemySpawnPointsContainer.childCount];

        for(int i = 0;i < enemySpawnPoints.Length; i++) {
            enemySpawnPoints[i] = enemySpawnPointsContainer.GetChild(i);
        }

        StartCoroutine(SpawnEnemy());
    }

    IEnumerator SpawnEnemy() {
        while (true) {
            if (enableSpawning) {
                if (enemiesCounter <= enemiesLimit) {
                    int randomEnemy = Random.Range(0, enemies.Length);

                    int randomSpawnPoint = Random.Range(0, enemySpawnPoints.Length);

                    GameObject tempEnemy = Instantiate(enemies[randomEnemy],
                                                       enemySpawnPoints[randomSpawnPoint].position,
                                                       enemySpawnPoints[randomSpawnPoint].rotation,
                                                       enemySpawnPoints[randomSpawnPoint]);

                    tempEnemy.GetComponent<EnemyBehaviour>().enemySpawner = this;


                    enemiesCounter++;
                }
            }
            
            

            yield return new WaitForSeconds(spawnDelay);
        }
    }


    public void DisableSpawnig() {
        enableSpawning = false;
    }
}
