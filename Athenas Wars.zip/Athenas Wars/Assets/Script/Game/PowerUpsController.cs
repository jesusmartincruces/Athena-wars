﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PowerUpsTypes
{
    Attack,
    Invencible
}
public class PowerUpsController : MonoBehaviour
{
    public bool powerUpActivated;

    [Header("Attack power up")]
    public float attackMultiplier;
    PlayerShoot pS;
    Damageable dM;

    

    // Start is called before the first frame update
    void Start()
    {
        pS = GetComponent<PlayerShoot>();
        dM = GetComponent<Damageable>();
    }


    public IEnumerator ActivatePowerUp(PowerUpsTypes pUpType,float duration) {
        powerUpActivated = true;

        switch (pUpType) {
            case PowerUpsTypes.Attack:
                yield return StartCoroutine(AttackPowerUp(duration));
                break;
            case PowerUpsTypes.Invencible:
                yield return StartCoroutine(InvenciblePowerUp(duration));
                break;
        }

        powerUpActivated = false;
    }


    public IEnumerator AttackPowerUp(float duration) {
        pS.bulletDamage *= attackMultiplier;
        yield return new WaitForSeconds(duration);
        pS.bulletDamage /= attackMultiplier;
    }

    public IEnumerator InvenciblePowerUp(float duration) {
        dM.invulnerable = true;
        yield return new WaitForSeconds(duration);
        dM.invulnerable = false;
    }

    
}
