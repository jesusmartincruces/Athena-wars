﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUpsSpawner : MonoBehaviour
{
    [Header("Collections")]
    public GameObject[ ] powerUps;

    public Transform powerUpsSpawnPointsContainer;
    public Transform[ ] powerUpsSpawnPoints;

    [Header("Spawn config")]
    public float spawnDelay;
    
    // Start is called before the first frame update
    void Start()
    {
        powerUpsSpawnPoints = new Transform[powerUpsSpawnPointsContainer.childCount];

        for (int i = 0; i < powerUpsSpawnPoints.Length; i++) {
            powerUpsSpawnPoints[i] = powerUpsSpawnPointsContainer.GetChild(i);
        }

        StartCoroutine(SpawnPowerUp());
    }

    // Update is called once per frame
  
    IEnumerator SpawnPowerUp() {
        while (true) {
            
               
             int randomPowerUp = Random.Range(0, powerUps.Length);

             int randomSpawnPoint = Random.Range(0, powerUpsSpawnPoints.Length);

            GameObject tempPower = Instantiate(powerUps[randomPowerUp],
                                           powerUpsSpawnPoints[randomSpawnPoint].position,
                                           Quaternion.identity);
            yield return new WaitForSeconds(spawnDelay);
        }
    }
}
