﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MineBehaviour : MonoBehaviour
{

    [HideInInspector] public float mineDamage;
    public Color overlapSphereColor;
    public float overlapSphereRadius;

    [HideInInspector] public float explosionForce;
    [HideInInspector] public float explosionRadius;
    [HideInInspector] public float upwardModifier;

    public GameObject explosionParticles;


    public IEnumerator Explosion(float delay) {
        yield return new WaitForSeconds(delay);

        Collider[ ] colls = Physics.OverlapSphere(transform.position, overlapSphereRadius);

        foreach (Collider col in colls) {
            if (col.CompareTag("Damageable")) {
                if(Physics.Raycast(transform.position, col.transform.position - transform.position, out RaycastHit hit)) {
                    if (hit.collider.CompareTag("Damageable")) {
                        col.GetComponent<Damageable>().GetDamage(false, mineDamage);
                        if(col.gameObject.layer == LayerMask.NameToLayer("Player")) {
                            col.GetComponent<Rigidbody>().AddExplosionForce(explosionForce, transform.position, explosionRadius);
                        }
                    }
                    
                }
            }
        }

        Instantiate(explosionParticles, transform.position, Quaternion.identity);

        Destroy(gameObject);
    }
    private void OnDrawGizmos() {
        Gizmos.color = overlapSphereColor;
        Gizmos.DrawSphere(transform.position, overlapSphereRadius);
    }
}
