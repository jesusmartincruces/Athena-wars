﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillMine : MonoBehaviour
{

    public GameObject minePrefab;

    [Header("Skill behaviour")]
    public int mineAmount;
    public float mineDamage;
    public float mineExplosionDelay;
    public float mineDelay;
    public float minePushValue;
    public float explosionForce;
    public float explosionRadius;
    public float upwardModifier;

    Transform spawnPoint;

    // Start is called before the first frame update
    void Start()
    {
        spawnPoint = transform.GetChild(0);
    }

   /* public override IEnumerator Skill() {
        for (int i = 0; i < mineAmount; i++) {
            GameObject tempMine = Instantiate(minePrefab, spawnPoint.position, spawnPoint.rotation);

            tempMine.GetComponent<Rigidbody>().AddForce(tempMine.transform.forward * minePushValue);

            MineBehaviour mb = tempMine.GetComponent<MineBehaviour>();

            mb.explosionForce = explosionForce;
            mb.explosionRadius = explosionRadius;
            mb.upwardModifier = upwardModifier;

            

            mb.mineDamage = mineDamage;

            mb.StartCoroutine(mb.Explosion(mineExplosionDelay));

            yield return new WaitForSeconds(mineDelay);
        }
    }*/
}
